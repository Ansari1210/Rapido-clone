from django.shortcuts import render, redirect
from .db import users_collection
import random

def register(request):
    if request.method == 'POST':
        if request.POST['password'] == request.POST['confirm']:
            users_collection.insert_one({
                "username": request.POST['username'],
                "email": request.POST['email'],
                "password": request.POST['password'],
            })
            return redirect('login')
    return render(request, 'register.html')

def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = users_collection.find_one({
            "email": email,
            "password": password
        })

        if user:
            return redirect(f'/home/?email={email}')
        else:
            return render(request, 'login.html', {"error": "Invalid email or password"})

    return render(request, 'login.html')



def home(request):
    email = request.GET.get('email')
    if not email:
        return redirect('login')
    user = users_collection.find_one({"email": email})
    return render(request, 'home.html', {'user': user})


def location(request):
    if request.method == 'POST':
        pickup = request.POST['pickup']
        drop = request.POST['drop']
        maps_url = f"https://www.google.com/maps?q={pickup}+to+{drop}&output=embed"

        return render(request, 'location.html', {
            'pickup': pickup,
            'drop': drop,
            'maps_url': maps_url
        })

    return render(request, 'location.html')


def vehicles(request):
        vehicles_data = [
            {"type": "Bike", "img": "bike.jpg", },
            {"type": "Auto",  "img": "auto.jpg", },
            {"type": "Car",  "img": "car.jpg", },
        ]
        return render(request, 'vehicles.html', {
            "vehicles": vehicles_data
        })


def payment(request):
    if request.method == 'POST':
        payment_method = request.POST.get('payment')
        upi_id = request.POST.get('upi_id')

        if payment_method == 'cash':
            return redirect('driver')

        elif payment_method == 'upi' and upi_id:
            return redirect('payment_success')

    return render(request, 'payment.html')

def payment_success(request):
    return render(request, 'payment_success.html')


def driver(request):
    drivers = [
        {"name": "Sulai", "number": "TN48AS5360"},
        {"name": "Arif", "number": "TN45AR6789"},
        {"name": "Asif", "number": "TN22CK9999"},
        {"name": "Mani", "number": "TN61AL4119"},
        {"name": "Vagee", "number": "TN32AM2512"},
    ]
    selected_driver = random.choice(drivers)
    return render(request, 'driver.html', {"driver": selected_driver})


def cancel(request):
    if request.method == 'POST':
        reason = request.POST.get('reason')
        return render(request, 'cancelled.html', {"reason": reason})
    return render(request, 'cancel.html')

def logout(request):
    return redirect('home')


