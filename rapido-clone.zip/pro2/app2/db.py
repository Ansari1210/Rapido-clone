from pymongo import MongoClient

client = MongoClient('mongodb+srv://ansari121004:drHNz98ttGfVpnG8@cluster0.mmeuzbk.mongodb.net/')

db = client['Ansari']

users_collection = db['users']
