from django.urls import path
from . import views

urlpatterns = [
    path('', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('home/', views.home, name='home'),
    path('location/', views.location, name='location'),
    path('vehicles/', views.vehicles, name='vehicles'),
    path('payment/', views.payment, name='payment'),
    path('driver/', views.driver, name='driver'),
    path('payment_success/', views.payment_success, name='payment_success'),
    path('cancel/', views.cancel, name='cancel'),
    path('logout/', views.logout, name='logout'),
]
